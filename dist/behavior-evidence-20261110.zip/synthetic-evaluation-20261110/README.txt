Synthetic business evaluation only. No real customer or business outcomes.
Reports are actual outputs; only workspace paths were anonymized.
Labels: A=basic agent without Skill, B=published baseline, C=0.2.0 candidate.
Read rubric.md and run-conditions.json before interpreting results.
Execution notes are executor records; graders did not independently inspect full tool traces.
This archive is evaluation evidence, not an installable Skill.
