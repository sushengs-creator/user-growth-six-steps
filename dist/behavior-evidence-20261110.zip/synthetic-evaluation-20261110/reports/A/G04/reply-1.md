已生成可直接打开的实验方案与结构化记录：

- [HTML方案](/evaluation/A/G04/G04-turn-1.html)
- [JSON记录](/evaluation/A/G04/G04-turn-1.json)

当前建议：先用单一入口改动，验证注册后24小时首题完成率是否提高；3/5访谈仅是线索，D7结果需等待完整观察窗口。
